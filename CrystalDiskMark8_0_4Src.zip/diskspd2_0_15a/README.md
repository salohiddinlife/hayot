DISKSPD
=======

DISKSPD is a storage load generator / performance test tool from the Windows/Windows Server and Cloud Server Infrastructure Engineering teams. Please see the included documentation (docx and pdf formats).

Compilation is supported with Visual Studio and Visual Studio Express. Use the Visual Studio solution file inside the diskspd_vs2013 directory.

Source code is hosted at the following repo, if you did not clone it directly:

[https://github.com/microsoft/diskspd](https://github.com/microsoft/diskspd "https://github.com/microsoft/diskspd")

A binary release is hosted by Microsoft at the following location:

[http://aka.ms/diskspd](http://aka.ms/diskspd "http://aka.ms/diskspd")
