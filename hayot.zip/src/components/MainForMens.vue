<template>
<section class="main__forMens">
  <div class="title">
    <span class="span"></span>
    <p class="text">Categories For Men</p>
  </div>
</section>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>