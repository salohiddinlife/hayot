<template>
  <section class="main__fashion">
    <div class="container">
      <div class="main__fashion-items">
        <div class="main__fashion-item1">
          <img
            src="/src/assets/img/fashionImg1.png"
            alt=""
            class="main__fashion-item1-img"
          />
          <div class="main__fashion-item1-content">
            <h2 class="main__fashion-item1-title">WE MADE YOUR EVERYDAY <br> FASHION BETTER!</h2>
          <p class="main__fashion-item1-text">
            In our journey to improve everyday fashion,<br> euphoria presents
            EVERYDAY wear range - <br> Comfortable & Affordable fashion 24/7
          </p>
          <button class="main__fashion-item1-btn">Shop Now</button>
          </div>
        </div>
        <div class="main__fashion-item2">
          <img
            src="/src/assets/img/fashionImg2.png"
            alt=""
            class="main__fashion-item2-img"
          />
        </div>
      </div>
    </div>
  </section>
</template>

<script setup></script>

<style lang="scss" scoped></style>
