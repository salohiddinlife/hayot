<template>
  <section class="main__forMens" v-if="products">
  <div class="title">
    <span class="span"></span>
    <p class="text">Categories For Men</p>
  </div>
  <div
   class="main__forMens-cards"
   v-for="(product, i) in products"
   :key="i"
   >
    <div 
    class="main__forMens-card"
    >
     <img :src="product.img" alt="" class="main__forMens-card-img">
    </div>
  </div>
</section>
</template>

<script setup>
import {  onMounted } from "vue";
import { useProductsStore } from "@/store/categories";

const store = useProductsStore();
const products = store.products;

const loadProducts = () => {
  store.getImgs();
};
onMounted(() => {
  loadProducts();
});
console.log(store);
</script>

<style lang="scss" scoped>

</style>