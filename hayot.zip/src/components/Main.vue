<template>
<main class="main">
    <Slider/>
    <SaleProducts/>
    <Arrivals/>
    <Saving/>
    <Fashion/>
    <ForMens/>
</main>
</template>

<script setup>
import Slider from '@/components/MainSlider.vue'
import SaleProducts from '@/components/MainSaleProducts.vue'
import Arrivals from '@/components/MainArrivals.vue'
import Saving from '@/components/MainSaving.vue'
import Fashion from '@/components/MainFashion.vue'
import ForMens from '@/components/MainForMens.vue'
import ForWomens from '@/components/MainForWomens.vue'
import Limelight from '@/components/MainLimeLight.vue'
import Reviews from '@/components/MainReviews.vue'

</script>

<style lang="scss" scoped>

</style>